class Cat implements MakesSound{
	public String makeNoise(){
		return "Meeow";
	}
}
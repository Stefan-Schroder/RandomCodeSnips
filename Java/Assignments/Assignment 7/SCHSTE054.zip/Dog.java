class Dog implements MakesSound{
	public String makeNoise(){
		return "Woof!";
	}
}
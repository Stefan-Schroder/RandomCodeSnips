public interface MakesSound{
	public String makeNoise();
}
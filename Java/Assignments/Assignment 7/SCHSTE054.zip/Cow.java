class Cow implements MakesSound{
	public String makeNoise(){
		return "Moo!";
	}
}
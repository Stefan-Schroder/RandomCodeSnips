#Stefan Schroder
#2048 merges
#2016-04-22

def push_up(grid):
    for y in range(1,4):#Moves up all numbers till no Zero gaps
        for x in range(4):
            if(grid[y][x]!=0):
                ZeroCount = 0
                for i in range(y-1,-1,-1):
                    if(grid[i][x]==0):
                        ZeroCount+=1
                if(ZeroCount!=0):
                    grid[ZeroCount-1][x]=grid[y][x]
                    grid[y][x]=0
    
    for y in range(1,4):
        for x in range(4):
            if(grid[y-1][x]==grid[y][x]):
                
    return grid

grid = [[0,2,0,0],
        [1,2,2,2],
        [0,0,0,0],
        [0,0,2,0]]

grid=push_up(grid)    
print(grid)